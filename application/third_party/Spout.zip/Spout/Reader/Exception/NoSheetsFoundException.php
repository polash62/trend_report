<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class NoSheetsFoundException
 *
 * @api
 * @package Box\Spout\Reader\Exception
 */
class NoSheetsFoundException extends ReaderException
{
}
