<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class InvalidColorException
 *
 * @api
 * @package Box\Spout\Writer\Exception
 */
class InvalidColorException extends WriterException
{
}
